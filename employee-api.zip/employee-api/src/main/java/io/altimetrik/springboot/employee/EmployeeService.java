package io.altimetrik.springboot.employee;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.*;

import org.springframework.stereotype.Service;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;

@Service
public class EmployeeService {

	private ArrayList<Employee> employees;

	public EmployeeService() {
		employees = new ArrayList<Employee>();
	}

	// Retrieving list of all employees
	public ArrayList<Employee> getAllEmployees() {
		FileInputStream fis = null;

		try {
			String fileName = "src/main/resources/Employee.csv";
			fis = new FileInputStream(new File(fileName));
			CSVReader reader = new CSVReader(new InputStreamReader(fis));
			String[] nextLine;
			reader.readNext();

			while ((nextLine = reader.readNext()) != null) {
				Employee employee = new Employee(Integer.valueOf(nextLine[0]), nextLine[1],
						Integer.valueOf(nextLine[2]), Integer.valueOf(nextLine[3]), nextLine[4]);
				employees.add(employee);
			}

		} catch (FileNotFoundException e) {
			Logger.getLogger(EmployeeService.class.getName()).log(Level.SEVERE, null, e);
		} catch (IOException e) {
			Logger.getLogger(EmployeeService.class.getName()).log(Level.SEVERE, null, e);
		}

		finally {
			try {
				if (fis != null) {
					fis.close();
				}
			} catch (IOException e) {
				Logger.getLogger(EmployeeService.class.getName()).log(Level.SEVERE, null, e);
			}
		}
		return employees;
	}

	// Retrieving list of an employee by Name
	public Employee getEmployee(String name) {
		FileInputStream fis = null;

		try {
			String fileName = "src/main/resources/Employee.csv";
			fis = new FileInputStream(new File(fileName));
			CSVReader reader = new CSVReader(new InputStreamReader(fis));
			String[] nextLine;
			reader.readNext();

			while ((nextLine = reader.readNext()) != null) {
				Employee employee = new Employee(Integer.valueOf(nextLine[0]), nextLine[1],
						Integer.valueOf(nextLine[2]), Integer.valueOf(nextLine[3]), nextLine[4]);
				employees.add(employee);
			}

		} catch (FileNotFoundException e) {
			Logger.getLogger(EmployeeService.class.getName()).log(Level.SEVERE, null, e);
		} catch (IOException e) {
			Logger.getLogger(EmployeeService.class.getName()).log(Level.SEVERE, null, e);
		}

		finally {
			try {
				if (fis != null) {
					fis.close();
				}
			} catch (IOException e) {
				Logger.getLogger(EmployeeService.class.getName()).log(Level.SEVERE, null, e);
			}
		}
		return employees.stream().filter(t -> t.getName().equals(name)).findFirst().get();
	}

	// Adding Employee details to the existing CSV file
	public void addEmployee(Employee employee) {
		FileOutputStream fos = null;
		FileInputStream fis = null;

		try {
			String fileName = "src/main/resources/Employee.csv";
			fos = new FileOutputStream(new File(fileName));
			CSVReader reader = new CSVReader(new InputStreamReader(fis));
			CSVWriter writer = new CSVWriter(new OutputStreamWriter(fos));
			String[] nextLine = null;
			writer.writeNext(nextLine);

			while ((nextLine = reader.readNext()) == null) {
				employee = new Employee(Integer.valueOf(nextLine[0]), nextLine[1], Integer.valueOf(nextLine[2]),
						Integer.valueOf(nextLine[3]), nextLine[4]);
				employees.add(employee);
			}

		} catch (FileNotFoundException e) {
			Logger.getLogger(EmployeeService.class.getName()).log(Level.SEVERE, null, e);
		} catch (IOException e) {
			Logger.getLogger(EmployeeService.class.getName()).log(Level.SEVERE, null, e);
		}

		finally {
			try {
				if (fos != null) {
					fos.close();
				}
			} catch (IOException e) {
				Logger.getLogger(EmployeeService.class.getName()).log(Level.SEVERE, null, e);
			}
		}
		
	}

	// Deleting Employee details by Name from the existing CSV file
	public void deleteEmployee(String name) {
		FileOutputStream fos = null;
		FileInputStream fis = null;

		try {
			String fileName = "src/main/resources/Employee.csv";
			fos = new FileOutputStream(new File(fileName));
			CSVReader reader = new CSVReader(new InputStreamReader(fis));
			CSVWriter writer = new CSVWriter(new OutputStreamWriter(fos));
			String[] nextLine = null;
			writer.writeNext(nextLine);

			while ((nextLine = reader.readNext()) != null) {
				Employee employee = new Employee(Integer.valueOf(nextLine[0]), nextLine[1],
						Integer.valueOf(nextLine[2]), Integer.valueOf(nextLine[3]), nextLine[4]);
				employees.add(employee);
			}

		} catch (FileNotFoundException e) {
			Logger.getLogger(EmployeeService.class.getName()).log(Level.SEVERE, null, e);
		} catch (IOException e) {
			Logger.getLogger(EmployeeService.class.getName()).log(Level.SEVERE, null, e);
		}

		finally {
			try {
				if (fos != null) {
					fos.close();
				}
			} catch (IOException e) {
				Logger.getLogger(EmployeeService.class.getName()).log(Level.SEVERE, null, e);
			}
		}

	}

	// Updating Employee details by Name from the existing CSV file
	public void updateEmployee(String name) {
		FileOutputStream fos = null;
		FileInputStream fis =null;

		try {
			String fileName = "src/main/resources/Employee.csv";
			fos = new FileOutputStream(new File(fileName));
			CSVReader reader = new CSVReader(new InputStreamReader(fis));
			CSVWriter writer = new CSVWriter(new OutputStreamWriter(fos));
			String[] nextLine = null;
			writer.writeNext(nextLine);

			while ((nextLine = reader.readNext()) != null) {
				Employee employee = new Employee(Integer.valueOf(nextLine[0]), nextLine[1],
						Integer.valueOf(nextLine[2]), Integer.valueOf(nextLine[3]), nextLine[4]);
				employees.add(employee);
			}

		} catch (FileNotFoundException e) {
			Logger.getLogger(EmployeeService.class.getName()).log(Level.SEVERE, null, e);
		} catch (IOException e) {
			Logger.getLogger(EmployeeService.class.getName()).log(Level.SEVERE, null, e);
		}

		finally {
			try {
				if (fos != null) {
					fos.close();
				}
			} catch (IOException e) {
				Logger.getLogger(EmployeeService.class.getName()).log(Level.SEVERE, null, e);
			}
		}

	}

}
