package io.altimetrik.springboot.employee;

import java.util.Date;

public class Employee {
	
	private int id;
	private String name;
	private int age;
	private int experience;
	private String dateOfJoining;
	
	public Employee()
	{
		
	}
	
	public Employee(int id, String name, int age, int experience, String dateOfJoining)
	{
		this.id=id;
		this.name=name;
		this.age=age;
		this.experience=experience;
		this.dateOfJoining=dateOfJoining;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getExperience() {
		return experience;
	}
	public void setExperience(int experience) {
		this.experience = experience;
	}
	public String getDateOfJoining() {
		return dateOfJoining;
	}
	public void setDateOfJoining(String dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}
	
	

}
